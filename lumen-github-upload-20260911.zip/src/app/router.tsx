import { Navigate, Route, Routes } from 'react-router-dom';
import { PlaceholderPage } from '../components/layout/PlaceholderPage';
import { DashboardPage } from '../features/executive-summary/DashboardPage';
import { MarketOverviewPage } from '../features/market/MarketOverviewPage';
import { PricingSimulatorPage } from '../features/pricing/PricingSimulatorPage';
import { ChannelAnalysisPage } from '../features/channels/ChannelAnalysisPage';
import { LaunchTimingPage } from '../features/timing/LaunchTimingPage';
import { LaunchPlanPage } from '../features/plan/LaunchPlanPage';
import { ValidateSharePage } from '../features/validate/ValidateSharePage';

const pages = [
  ['summary', 'Decision Home', 'A clear starting point for the launch decision.'],
  ['plan', 'Build a Launch Plan', 'Shape a launch plan through a guided workflow.'],
  ['pricing', 'Pricing Simulator', 'Explore price, demand, and contribution scenarios.'],
  ['channels', 'Channel Analysis', 'Compare channel profitability and acquisition efficiency.'],
  ['timing', 'Launch Timing', 'Balance seasonality, weather, and competitor activity.'],
  ['market', 'Understand the Market', 'Explore customers, geography, and competition.'],
  ['validate', 'Validate and Share', 'Review assumptions and prepare a decision summary.'],
] as const;

export function AppRoutes() {
  return <Routes>
    <Route path="/" element={<Navigate to="/summary" replace />} />
    {pages.map(([path, title, description]) => <Route key={path} path={`/${path}`} element={path === 'summary' ? <DashboardPage /> : path === 'plan' ? <LaunchPlanPage /> : path === 'market' ? <MarketOverviewPage /> : path === 'pricing' ? <PricingSimulatorPage /> : path === 'channels' ? <ChannelAnalysisPage /> : path === 'timing' ? <LaunchTimingPage /> : path === 'validate' ? <ValidateSharePage /> : <PlaceholderPage title={title} description={description} />} />)}
    <Route path="*" element={<Navigate to="/summary" replace />} />
  </Routes>;
}
