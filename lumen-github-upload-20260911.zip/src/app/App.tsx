import { BrowserRouter } from 'react-router-dom';
import { AppRoutes } from './router';
import { AppShell } from '../components/layout/AppShell';
import { ErrorBoundary } from '../components/feedback/ErrorBoundary';

export function App() {
  return <ErrorBoundary><BrowserRouter><AppShell><AppRoutes /></AppShell></BrowserRouter></ErrorBoundary>;
}
