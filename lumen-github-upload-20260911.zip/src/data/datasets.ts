import { CsvRow } from './core';

export interface CustomerSurveyRow extends CsvRow { respondent_id: string; segment: string; city: string; age: number; purchase_frequency_per_month: number; monthly_beverage_spend_eur: number; price_sensitivity_1_10: number; preferred_channel: string; lumen_purchase_intent_1_10: number; }
export interface ChannelEconomicsRow extends CsvRow { channel: string; illustrative_retail_price_eur: number; net_price_to_lumen_eur: number; unit_contribution_eur: number; }
export interface PriceTestRow extends CsvRow { price_eur: number; channel: string; estimated_acceptance_pct_of_survey: number; unit_contribution_eur: number; contribution_margin_pct: number; }
export interface HistoricalSalesRow extends CsvRow { week_start_date: string; country: string; channel: string; units_sold: number; revenue_eur: number; promo_active: boolean; }

/** Removes direct identifiers before customer data enters application state. */
export function toSafeCustomerRows(rows: CustomerSurveyRow[]): Omit<CustomerSurveyRow, 'first_name' | 'last_name' | 'email'>[] {
  return rows.map(({ first_name: _first, last_name: _last, email: _email, ...safe }) => safe);
}
