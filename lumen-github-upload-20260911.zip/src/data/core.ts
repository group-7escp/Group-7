export type CsvValue = string | number | boolean | null;
export type CsvRow = Record<string, CsvValue>;

export type FieldType = 'string' | 'number' | 'integer' | 'boolean' | 'date';

export interface FieldSchema {
  type: FieldType;
  required?: boolean;
  nullable?: boolean;
  min?: number;
  max?: number;
}

export interface DatasetSchema {
  name: string;
  fields: Record<string, FieldSchema>;
  uniqueBy?: string[];
}

export interface ValidationIssue {
  row: number;
  field?: string;
  code: 'missing-column' | 'missing-value' | 'invalid-type' | 'out-of-range' | 'duplicate-key' | 'invalid-header' | 'invalid-row-width';
  message: string;
  value?: CsvValue;
}

export interface ValidationResult<T extends CsvRow = CsvRow> {
  valid: boolean;
  rows: T[];
  issues: ValidationIssue[];
}

export class DataLayerError extends Error {
  constructor(message: string, public readonly cause?: unknown) {
    super(message);
    this.name = 'DataLayerError';
  }
}

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;

  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    const next = text[i + 1];
    if (char === '"') {
      if (quoted && next === '"') { cell += '"'; i += 1; }
      else { quoted = !quoted; }
    } else if (char === ',' && !quoted) {
      row.push(cell); cell = '';
    } else if ((char === '\n' || char === '\r') && !quoted) {
      if (char === '\r' && next === '\n') i += 1;
      row.push(cell); cell = '';
      if (row.some(value => value.trim() !== '')) rows.push(row);
      row = [];
    } else cell += char;
  }
  if (quoted) throw new DataLayerError('CSV contains an unterminated quoted field.');
  if (cell !== '' || row.length) { row.push(cell); if (row.some(value => value.trim() !== '')) rows.push(row); }
  return rows;
}

export function parseValue(raw: string, schema?: FieldSchema): CsvValue {
  const value = raw.trim();
  if (value === '') return null;
  if (!schema || schema.type === 'string') return value;
  if (schema.type === 'number' || schema.type === 'integer') {
    const number = Number(value);
    return Number.isFinite(number) ? number : value;
  }
  if (schema.type === 'boolean') {
    if (/^(true|1|yes)$/i.test(value)) return true;
    if (/^(false|0|no)$/i.test(value)) return false;
    return value;
  }
  return value;
}

export function rowsFromCsv<T extends CsvRow = CsvRow>(text: string, schema?: DatasetSchema): T[] {
  const matrix = parseCsv(text);
  if (!matrix.length) return [];
  const headers = matrix[0].map(header => header.trim().replace(/^\uFEFF/, ''));
  if (headers.some(header => !header)) throw new DataLayerError('CSV contains an empty column name.');
  return matrix.slice(1).map((values, rowIndex) => {
    if (values.length !== headers.length) throw new DataLayerError(`Row ${rowIndex + 2} has ${values.length} values; expected ${headers.length}.`);
    return Object.fromEntries(headers.map((header, index) => [header, parseValue(values[index], schema?.fields[header])])) as T;
  });
}

function matchesType(value: CsvValue, type: FieldType): boolean {
  if (type === 'string' || type === 'date') return typeof value === 'string';
  if (type === 'number') return typeof value === 'number';
  if (type === 'integer') return typeof value === 'number' && Number.isInteger(value);
  return typeof value === 'boolean';
}

export function validateRows<T extends CsvRow>(rows: T[], schema: DatasetSchema): ValidationResult<T> {
  const issues: ValidationIssue[] = [];
  const expected = Object.keys(schema.fields);
  expected.forEach(field => { if (!rows.length || !(field in rows[0])) issues.push({ row: 1, field, code: 'missing-column', message: `Missing required column: ${field}` }); });
  const keys = new Set<string>();
  rows.forEach((row, index) => {
    const rowNumber = index + 2;
    Object.entries(schema.fields).forEach(([field, rules]) => {
      const value = row[field];
      if (value === null) { if (rules.required && !rules.nullable) issues.push({ row: rowNumber, field, code: 'missing-value', message: `Missing value for ${field}`, value }); return; }
      if (!matchesType(value, rules.type)) issues.push({ row: rowNumber, field, code: 'invalid-type', message: `Expected ${rules.type} for ${field}`, value });
      if (typeof value === 'number' && rules.min !== undefined && value < rules.min || typeof value === 'number' && rules.max !== undefined && value > rules.max) issues.push({ row: rowNumber, field, code: 'out-of-range', message: `Value outside allowed range for ${field}`, value });
    });
    if (schema.uniqueBy?.length) { const key = schema.uniqueBy.map(field => String(row[field] ?? '')).join('¦'); if (keys.has(key)) issues.push({ row: rowNumber, code: 'duplicate-key', message: `Duplicate key: ${key}` }); keys.add(key); }
  });
  return { valid: issues.length === 0, rows, issues };
}
