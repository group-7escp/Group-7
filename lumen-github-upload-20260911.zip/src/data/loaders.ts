import { DataLayerError, DatasetSchema, CsvRow, rowsFromCsv, validateRows, ValidationResult } from './core';

export async function loadCsvText(source: string | URL, init?: RequestInit): Promise<string> {
  try {
    const response = await fetch(source, init);
    if (!response.ok) throw new DataLayerError(`Unable to load CSV (${response.status}): ${String(source)}`);
    return await response.text();
  } catch (error) {
    if (error instanceof DataLayerError) throw error;
    throw new DataLayerError(`Unable to load CSV: ${String(source)}`, error);
  }
}

export async function loadDataset<T extends CsvRow>(source: string | URL, schema: DatasetSchema, init?: RequestInit): Promise<ValidationResult<T>> {
  const text = await loadCsvText(source, init);
  const rows = rowsFromCsv<T>(text, schema);
  return validateRows(rows, schema);
}

export function normalizeCategory(value: unknown): string {
  return String(value ?? '').trim().replace(/\s+/g, ' ');
}

export function normalizeCategories<T extends CsvRow>(rows: T[], fields: string[]): T[] {
  return rows.map(row => Object.fromEntries(Object.entries(row).map(([key, value]) => [key, fields.includes(key) ? normalizeCategory(value) : value])) as T);
}

export function aggregateBy<T extends CsvRow>(rows: T[], field: keyof T): Map<string, T[]> {
  return rows.reduce((groups, row) => { const key = normalizeCategory(row[field]); const group = groups.get(key) ?? []; group.push(row); groups.set(key, group); return groups; }, new Map<string, T[]>());
}
