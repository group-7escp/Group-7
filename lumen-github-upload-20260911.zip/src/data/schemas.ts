import { DatasetSchema } from './core';

const text = { type: 'string' as const, required: true };
const number = { type: 'number' as const, required: true };
const percent = { ...number, min: 0, max: 100 };

export const schemas: Record<string, DatasetSchema> = {
  marketContext: { name: 'market_context', fields: { dimension_type: text, name: text, metric: text, value: number, unit: text, year: { type: 'integer', required: true }, notes: { type: 'string', nullable: true } } },
  competitorPrices: { name: 'competitor_prices_by_channel', fields: { competitor: text, positioning: text, channel: text, format: text, price_eur: number, marketing_spend_index_0_100: { ...number, min: 0, max: 100 } } },
  competitorPriceHistory: { name: 'competitor_price_history', fields: { competitor: text, month: text, list_price_eur: number, promo_active: { type: 'boolean', required: true }, promo_discount_pct: percent, shelf_price_eur: number }, uniqueBy: ['competitor', 'month'] },
  customerSurvey: { name: 'customer_survey', fields: { respondent_id: text, first_name: { type: 'string', nullable: true }, last_name: { type: 'string', nullable: true }, email: { type: 'string', nullable: true }, segment: text, age: { type: 'integer', required: true, min: 13 }, city: text, purchase_frequency_per_month: number, monthly_beverage_spend_eur: number, price_sensitivity_1_10: { ...number, min: 1, max: 10 }, preferred_channel: text, aware_pulsup: { type: 'boolean', required: true }, aware_matelibre: { type: 'boolean', required: true }, aware_voltfit: { type: 'boolean', required: true }, aware_rootandrise: { type: 'boolean', required: true }, lumen_purchase_intent_1_10: { ...number, min: 1, max: 10 } }, uniqueBy: ['respondent_id'] },
  customerQuotes: { name: 'customer_quotes', fields: { segment: text, sentiment: text, quote: text } },
  historicalSales: { name: 'historical_sales_weekly', fields: { week_start_date: { type: 'date', required: true }, country: text, channel: text, units_sold: { ...number, min: 0 }, revenue_eur: { ...number, min: 0 }, promo_active: { type: 'boolean', required: true } }, uniqueBy: ['week_start_date', 'country', 'channel'] },
  marketingFunnel: { name: 'marketing_funnel_monthly', fields: { month: text, channel: text, reach: { ...number, min: 0 }, engagements: { ...number, min: 0 }, conversions: { ...number, min: 0 }, customers_acquired: { ...number, min: 0 }, spend_eur: { ...number, min: 0 }, cac_eur: { ...number, min: 0 }, ltv_estimate_eur: { ...number, min: 0 } } },
  costBreakdown: { name: 'cost_breakdown', fields: { cost_component: text, cost_per_unit_eur: { ...number, min: 0 }, pct_of_total: percent } },
  channelEconomics: { name: 'channel_economics', fields: { channel: text, illustrative_retail_price_eur: { ...number, min: 0 }, retailer_margin_pct: percent, distributor_cut_pct: percent, payment_processing_pct: percent, fulfillment_cost_eur: { ...number, min: 0 }, net_price_to_lumen_eur: number, unit_contribution_eur: number } },
  priceSensitivity: { name: 'price_sensitivity_survey', fields: { respondent_id: text, segment: text, too_cheap_eur: number, cheap_eur: number, expensive_eur: number, too_expensive_eur: number }, uniqueBy: ['respondent_id'] },
  priceTests: { name: 'price_test_results', fields: { price_eur: number, channel: text, estimated_acceptance_pct_of_survey: percent, net_price_to_lumen_eur: number, unit_contribution_eur: number, contribution_margin_pct: percent } },
  seasonality: { name: 'seasonality_and_weather', fields: { month: text, seasonality_index_100_avg: number, avg_temp_germany_celsius: number }, uniqueBy: ['month'] },
};
