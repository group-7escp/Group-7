import { parseCsv, parseValue, rowsFromCsv, validateRows } from '../core';

describe('CSV data layer', () => {
  it('parses quoted commas and escaped quotes', () => {
    expect(parseCsv('name,quote\nLUMEN,"A, \"bright\" choice"')).toEqual([['name', 'quote'], ['LUMEN', 'A, "bright" choice']]);
  });

  it('parses typed values and blank values', () => {
    expect(parseValue('42', { type: 'number' })).toBe(42);
    expect(parseValue('true', { type: 'boolean' })).toBe(true);
    expect(parseValue('', { type: 'number' })).toBeNull();
  });

  it('reports invalid values and duplicate keys', () => {
    const schema = { name: 'test', fields: { id: { type: 'integer' as const, required: true }, score: { type: 'number' as const, required: true, min: 0, max: 10 } }, uniqueBy: ['id'] };
    const rows = rowsFromCsv('id,score\n1,12\n1,4', schema);
    const result = validateRows(rows, schema);
    expect(result.valid).toBe(false);
    expect(result.issues.some(issue => issue.code === 'out-of-range')).toBe(true);
    expect(result.issues.some(issue => issue.code === 'duplicate-key')).toBe(true);
  });
});
