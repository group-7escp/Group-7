export type Channel = 'DTC Online' | 'Retail/Grocery' | 'Gym & Office';
export interface PriceScenario { price: number; acceptance: number; netRevenue: number; contribution: number; revenue: number; profit: number; }

const channels: Record<Channel, { netAt219: number; contributionAt219: number; share: number }> = {
  'DTC Online': { netAt219: 1.78, contributionAt219: 1.16, share: 0.35 },
  'Retail/Grocery': { netAt219: 1.25, contributionAt219: 0.63, share: 0.30 },
  'Gym & Office': { netAt219: 1.75, contributionAt219: 1.13, share: 0.35 },
};
const acceptance: Record<number, number> = { 1.79: 0.617, 2.19: 0.517, 2.59: 0.267 };

export function estimateScenario(price: number, marketSize = 10000, demandAdjustment = 0): PriceScenario {
  if (!Number.isFinite(price) || price <= 0) throw new RangeError('Price must be a positive finite number.');
  if (!Number.isFinite(marketSize) || marketSize < 0) throw new RangeError('Market size must be a non-negative finite number.');
  const safeAdjustment = Number.isFinite(demandAdjustment) ? demandAdjustment : 0;
  const baseAcceptance = acceptance[price] ?? Math.max(0.05, 0.517 - (price - 2.19) * 0.42);
  const accepted = Math.min(1, Math.max(0, baseAcceptance * (1 + safeAdjustment / 100)));
  const weightedContribution = Object.values(channels).reduce((total, channel) => total + channel.contributionAt219 * (price / 2.19) * channel.share, 0);
  const weightedNet = Object.values(channels).reduce((total, channel) => total + channel.netAt219 * (price / 2.19) * channel.share, 0);
  const units = marketSize * accepted;
  return { price, acceptance: accepted, netRevenue: weightedNet, contribution: weightedContribution, revenue: units * price, profit: units * weightedContribution };
}

export function estimateSensitivity(price: number, adjustment: number): PriceScenario[] {
  return [-20, -10, 0, 10, 20].map(delta => estimateScenario(price, 10000, adjustment + delta));
}
