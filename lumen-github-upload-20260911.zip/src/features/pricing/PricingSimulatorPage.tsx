import { useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { PriceSelector } from '../../components/pricing/PriceSelector';
import { SimulatorChart } from '../../components/pricing/SimulatorChart';
import { estimateScenario, estimateSensitivity } from './pricingModel';
import { getScenario } from '../../domain/scenarios/scenarios';
import './pricing.css';

const prices = [1.79, 2.19, 2.59];

export function PricingSimulatorPage() {
  const location = useLocation();
  const scenario = getScenario(new URLSearchParams(location.search).get('scenario'));
  const [selectedPrice, setSelectedPrice] = useState(scenario.price);
  const [demandAdjustment, setDemandAdjustment] = useState(0);
  const result = useMemo(() => estimateScenario(selectedPrice, 10000, demandAdjustment), [selectedPrice, demandAdjustment]);
  const comparison = useMemo(() => prices.map(price => estimateScenario(price)), []);
  const sensitivity = useMemo(() => estimateSensitivity(selectedPrice, demandAdjustment), [selectedPrice, demandAdjustment]);
  return <section className="pricing-page">
    <div className="pricing-heading"><div><span className="eyebrow">LUMEN GERMANY · SIMULATOR</span><h1>Pricing Simulator</h1><p>Explore the demand and profit implications of each candidate price.</p></div><span className="data-badge">Presentation model</span></div>
    <section className="pricing-controls"><div><span className="control-label">Candidate launch price</span><PriceSelector prices={prices} selected={selectedPrice} onChange={setSelectedPrice} /></div><label className="demand-control"><span className="control-label">Demand sensitivity adjustment <strong>{demandAdjustment > 0 ? '+' : ''}{demandAdjustment}%</strong></span><input type="range" min="-20" max="20" step="5" value={demandAdjustment} onChange={event => setDemandAdjustment(Number(event.target.value))} /><span className="range-labels"><span>Lower demand</span><span>Higher demand</span></span></label></section>
    <section className="selected-result" aria-label="Selected price result"><div><span className="eyebrow">SELECTED SCENARIO</span><h2>€{selectedPrice.toFixed(2)} launch price</h2><p>Updates instantly when you change the candidate price or demand assumption.</p></div><div className="result-metrics"><div><span>Demand estimate</span><strong>{(result.acceptance * 100).toFixed(1)}%</strong></div><div><span>Contribution / unit</span><strong>€{result.contribution.toFixed(2)}</strong></div><div><span>Estimated profit</span><strong>€{result.profit.toLocaleString('en-GB', { maximumFractionDigits: 0 })}</strong></div></div></section>
    <div className="pricing-grid"><section className="pricing-panel"><div className="panel-header"><div><span className="eyebrow">CANDIDATE COMPARISON</span><h2>Demand estimation</h2></div></div><SimulatorChart title="Estimated acceptance by price" items={comparison.map(item => ({ label: `€${item.price.toFixed(2)}`, value: item.acceptance * 100 }))} suffix="" selected={`€${selectedPrice.toFixed(2)}`} /><div className="comparison-table"><div><span>Price</span><span>Acceptance</span><span>Revenue</span></div>{comparison.map(item => <div className={item.price === selectedPrice ? 'active' : ''} key={item.price}><strong>€{item.price.toFixed(2)}</strong><span>{(item.acceptance * 100).toFixed(1)}%</span><span>€{item.revenue.toLocaleString('en-GB', { maximumFractionDigits: 0 })}</span></div>)}</div></section><section className="pricing-panel"><div className="panel-header"><div><span className="eyebrow">PROFITABILITY</span><h2>Revenue vs profit</h2></div></div><SimulatorChart title="Selected scenario economics" items={[{ label: 'Revenue', value: result.revenue / 1000 }, { label: 'Profit', value: result.profit / 1000 }]} suffix="€" /><div className="chart-footnote">Values shown in thousands for the selected 10,000-unit opportunity base.</div></section></div>
    <section className="pricing-panel sensitivity-panel"><div className="panel-header"><div><span className="eyebrow">ROBUSTNESS CHECK</span><h2>Sensitivity analysis</h2><p>See how estimated profit changes when demand is higher or lower than the base assumption.</p></div><span className="data-badge">Interactive</span></div><div className="sensitivity-list">{sensitivity.map((item, index) => <div className={index === 2 ? 'base' : ''} key={index}><span>{index === 2 ? 'Base' : `${index < 2 ? (index - 2) * 10 : (index - 2) * 10 > 0 ? '+' : ''}${(index - 2) * 10}% demand`}</span><div className="sensitivity-track"><i style={{ width: `${Math.max(8, item.profit / Math.max(...sensitivity.map(entry => entry.profit)) * 100)}%` }} /></div><strong>€{item.profit.toLocaleString('en-GB', { maximumFractionDigits: 0 })}</strong></div>)}</div></section>
  </section>;
}
