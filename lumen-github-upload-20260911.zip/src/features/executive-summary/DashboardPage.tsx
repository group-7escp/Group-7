import './dashboard.css';
import { generateRecommendation } from '../../domain/recommendations/recommendationEngine';
import { RecommendationPanel } from '../../components/recommendations/RecommendationPanel';
import { NavLink } from 'react-router-dom';
import { SimulatorChart } from '../../components/pricing/SimulatorChart';
import { useLocation } from 'react-router-dom';
import { getScenario } from '../../domain/scenarios/scenarios';
import { estimateScenario } from '../pricing/pricingModel';

export function DashboardPage() {
  const location = useLocation();
  const scenario = getScenario(new URLSearchParams(location.search).get('scenario'));
  const recommendation = generateRecommendation({ price: scenario.price, cacAdjustment: scenario.cacAdjustment, customerDemand: 0.517 * (1 + scenario.demandAdjustment / 100) });
  const pricePoints = [1.79, 2.19, 2.59];
  const tradeoffItems = pricePoints.map(price => ({ label: `€${price.toFixed(2)}`, value: estimateScenario(price, 10000, scenario.demandAdjustment).contribution }));
  const kpis = [
    ['Expected contribution', `€${recommendation.metrics.contribution.toFixed(2)} / unit`, 'Modelled from current scenario'],
    ['Payback period', `${Math.ceil(44 / recommendation.metrics.contribution)} units`, 'Illustrative CAC recovery'],
    ['Estimated acceptance', `${(recommendation.metrics.acceptance * 100).toFixed(1)}%`, 'Modelled demand estimate'],
    ['LTV : CAC', `${recommendation.metrics.ltvCac.toFixed(1)}×`, 'Weighted channel estimate'],
  ];
  return <section className="dashboard-page">
    <div className="dashboard-heading"><div><span className="eyebrow">LUMEN GERMANY · {scenario.positioning.toUpperCase()}</span><h1>Decision Home</h1><p>Turn the launch question into a clear, testable commercial plan.</p></div><NavLink className="primary-button" to={`/plan?scenario=${scenario.key}`}>Build a launch plan <span aria-hidden="true">→</span></NavLink></div>
    <section className="recommendation-banner recommendation-banner--expanded"><div className="recommendation-mark" aria-hidden="true">✦</div><RecommendationPanel result={recommendation} /><span className="status-chip">Modelled</span></section>
    <div className="kpi-grid" aria-label="Key performance indicators">{kpis.map(([label, value, helper]) => <article className="kpi-card" key={label}><span className="kpi-label">{label}</span><strong>{value}</strong><span className="kpi-helper">{helper}</span></article>)}</div>
    <div className="dashboard-grid"><section className="panel panel--wide" aria-labelledby="tradeoff-title"><div className="panel-header"><div><span className="eyebrow">DECISION SUPPORT</span><h2 id="tradeoff-title">Price and contribution trade-off</h2></div><NavLink className="text-button" to={`/pricing?scenario=${scenario.key}`}>Open simulator <span aria-hidden="true">→</span></NavLink></div><SimulatorChart title="Estimated contribution by candidate price" items={tradeoffItems} selected={`€${scenario.price.toFixed(2)}`} /><p className="chart-footnote">Illustrative contribution per unit for the selected launch scenario.</p></section><section className="panel" aria-labelledby="risk-title"><div className="panel-header"><div><span className="eyebrow">WATCH ITEMS</span><h2 id="risk-title">What could change the answer?</h2></div></div><div className="risk-summary">{recommendation.risks.map(risk => <div key={risk.label}><span className={`risk-dot risk-dot--${risk.severity}`} /><p><strong>{risk.label}</strong><small>{risk.mitigation}</small></p></div>)}</div></section></div>
    <section className="panel data-status" aria-labelledby="status-title"><div className="panel-header"><div><span className="eyebrow">WORKSPACE STATUS</span><h2 id="status-title">Your decision workspace is ready</h2></div><span className="status-chip status-chip--soft">Modelled data</span></div><div className="workspace-status-grid"><div className="status-row"><span className="status-indicator" aria-hidden="true">✓</span><div><strong>Data layer</strong><p>Illustrative CSV inputs loaded</p></div></div><div className="status-row"><span className="status-indicator" aria-hidden="true">✓</span><div><strong>Decision engine</strong><p>Recommendation metrics available</p></div></div><div className="status-row"><span className="status-indicator" aria-hidden="true">→</span><div><strong>Next step</strong><p>Build and validate the launch plan</p></div></div></div></section>
  </section>;
}
