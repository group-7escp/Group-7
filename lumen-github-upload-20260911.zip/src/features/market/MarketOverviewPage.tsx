import { useState } from 'react';
import { InteractiveBarChart, BarDatum } from '../../components/market/InteractiveBarChart';
import { MarketKpiCard } from '../../components/market/MarketKpiCard';
import './market.css';

const marketSize: BarDatum[] = [
  { label: '2022', value: 7.2, detail: 'Historical context' },
  { label: '2023', value: 7.7, detail: 'Category expansion' },
  { label: '2024', value: 8.2, detail: 'Category expansion' },
  { label: '2025', value: 8.7, detail: 'Pre-launch baseline' },
  { label: '2026', value: 9.1, detail: 'Current market estimate' },
  { label: '2027', value: 9.7, detail: 'Forward estimate' },
];

const regional: BarDatum[] = [
  { label: 'Berlin', value: 86, detail: 'Illustrative opportunity index' },
  { label: 'Munich', value: 78, detail: 'Illustrative opportunity index' },
  { label: 'Hamburg', value: 69, detail: 'Illustrative opportunity index' },
  { label: 'Cologne', value: 61, detail: 'Illustrative opportunity index' },
  { label: 'Frankfurt', value: 57, detail: 'Illustrative opportunity index' },
];

const competitors = [
  ['PulsUp', 'Mass market', '€1.00–1.30', 'Low'],
  ['Mate Libre', 'Heritage / niche', '€1.40–1.80', 'Medium'],
  ['VoltFit', 'Premium performance', '€2.10–2.70', 'High'],
  ['Root & Rise', 'Boutique adaptogenic', '€2.50–3.10', 'High'],
];

export function MarketOverviewPage() {
  const [view, setView] = useState<'size' | 'regional'>('size');
  return <section className="market-page">
    <div className="market-heading"><div><span className="eyebrow">LUMEN GERMANY</span><h1>Market Overview</h1><p>Understand the opportunity, competitive landscape, and first places to learn.</p></div><span className="data-badge">12 source datasets</span></div>
    <div className="market-kpi-grid"><MarketKpiCard label="German category size" value="€9.1bn" detail="2026 estimate" tone="highlight" /><MarketKpiCard label="Category growth" value="~7%" detail="CAGR through 2033" /><MarketKpiCard label="European share" value="~35%" detail="Germany share of category value" /><MarketKpiCard label="Established competitors" value="4" detail="Benchmarked brands" /></div>
    <div className="market-grid"><section className="market-panel market-panel--large"><div className="market-panel-header"><div><span className="eyebrow">OPPORTUNITY</span><h2>{view === 'size' ? 'Market size trajectory' : 'Regional opportunity index'}</h2></div><div className="segmented-control" role="group" aria-label="Market view"><button type="button" className={view === 'size' ? 'active' : ''} onClick={() => setView('size')}>Market size</button><button type="button" className={view === 'regional' ? 'active' : ''} onClick={() => setView('regional')}>Regions</button></div></div><p className="chart-note">Select a bar to inspect the supporting context.</p><InteractiveBarChart data={view === 'size' ? marketSize : regional} suffix={view === 'size' ? 'bn' : ''} color={view === 'size' ? 'green' : 'dark'} /></section>
      <section className="market-panel"><div className="market-panel-header"><div><span className="eyebrow">MARKET SIGNAL</span><h2>What matters now</h2></div></div><div className="signal-list"><div><span className="signal-icon">↗</span><p><strong>Large, growing category</strong><small>Growth creates room for a differentiated entrant.</small></p></div><div><span className="signal-icon">◎</span><p><strong>Premium space exists</strong><small>VoltFit and Root & Rise establish higher price expectations.</small></p></div><div><span className="signal-icon">⌖</span><p><strong>Focus improves learning</strong><small>A city-led launch can concentrate limited marketing resources.</small></p></div></div></section></div>
    <section className="market-panel competitor-panel"><div className="market-panel-header"><div><span className="eyebrow">COMPETITIVE LANDSCAPE</span><h2>Competitor overview</h2></div><span className="chart-note">Positioning is from the market brief</span></div><div className="competitor-table" role="table" aria-label="Competitor overview"><div className="competitor-row competitor-row--head" role="row"><span>Brand</span><span>Positioning</span><span>Price band</span><span>Marketing intensity</span></div>{competitors.map(([brand, positioning, price, intensity]) => <div className="competitor-row" role="row" key={brand}><strong>{brand}</strong><span>{positioning}</span><span>{price}</span><span><i className={`intensity intensity--${intensity.toLowerCase()}`} />{intensity}</span></div>)}</div></section>
    <section className="market-panel market-next"><div><span className="eyebrow">NEXT STEP</span><h2>Ready to connect the market view to a launch plan?</h2><p>This overview is intentionally independent from pricing. The next planning phase can use the selected region as an input.</p></div><button type="button" className="text-button">Open launch planner <span aria-hidden="true">→</span></button></section>
  </section>;
}
