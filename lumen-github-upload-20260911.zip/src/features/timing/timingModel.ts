export interface TimingMonth { month: string; seasonality: number; temperature: number; competitorActivity: number; score: number; uncertainty: number; }

const source = [
  ['Jan', 76, 1, 42], ['Feb', 80, 3, 38], ['Mar', 91, 7, 31], ['Apr', 98, 11, 27],
  ['May', 108, 15, 36], ['Jun', 116, 18, 49], ['Jul', 121, 20, 61], ['Aug', 118, 20, 57],
  ['Sep', 107, 16, 44], ['Oct', 96, 11, 32], ['Nov', 84, 6, 28], ['Dec', 79, 2, 52],
] as const;

export function buildTimingModel(): TimingMonth[] {
  return source.map(([month, seasonality, temperature, competitorActivity]) => {
    const demand = seasonality / 121;
    const temperatureFit = Math.max(0, Math.min(1, (temperature + 2) / 22));
    const competitiveHeadwind = competitorActivity / 100;
    const score = Math.round((demand * 55 + temperatureFit * 25 + (1 - competitiveHeadwind) * 20) * 100) / 100;
    const uncertainty = Math.round(7 + (competitorActivity > 50 ? 5 : 0) + (seasonality < 85 ? 3 : 0));
    return { month, seasonality, temperature, competitorActivity, score, uncertainty };
  });
}

export function getOptimalWindow(months: TimingMonth[]): TimingMonth[] {
  if (!months.length) return [];
  return [...months].sort((a, b) => b.score - a.score).slice(0, Math.min(3, months.length)).sort((a, b) => months.indexOf(a) - months.indexOf(b));
}
