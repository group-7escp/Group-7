export type ChannelName = 'DTC Online' | 'Retail/Grocery' | 'Gym & Office';
export interface ChannelResult { channel: ChannelName; contribution: number; cac: number; ltv: number; ltvCac: number; paybackUnits: number; netRevenue: number; }

const base: Record<ChannelName, Omit<ChannelResult, 'ltvCac' | 'paybackUnits'>> = {
  'DTC Online': { channel: 'DTC Online', contribution: 1.16, cac: 44, ltv: 132, netRevenue: 1.78 },
  'Retail/Grocery': { channel: 'Retail/Grocery', contribution: 0.63, cac: 44, ltv: 105, netRevenue: 1.25 },
  'Gym & Office': { channel: 'Gym & Office', contribution: 1.13, cac: 44, ltv: 125, netRevenue: 1.75 },
};

export function getChannelResults(cacAdjustment = 0): ChannelResult[] {
  const safeAdjustment = Number.isFinite(cacAdjustment) ? Math.max(-99, cacAdjustment) : 0;
  return Object.values(base).map(item => { const cac = item.cac * (1 + safeAdjustment / 100); return { ...item, cac, ltvCac: item.ltv / cac, paybackUnits: cac / item.contribution }; });
}
