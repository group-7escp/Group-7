import { TimingMonth } from '../../features/timing/timingModel';

export function TimingLineChart({ months, metric, selected, onSelect }: { months: TimingMonth[]; metric: 'seasonality' | 'temperature' | 'competitorActivity'; selected: string; onSelect: (month: string) => void }) {
  const labels = { seasonality: 'Seasonality index', temperature: 'Average temperature', competitorActivity: 'Competitor activity' };
  const values = months.map(item => item[metric]); const max = Math.max(...values, 1); const min = Math.min(...values, 0); const range = max - min || 1;
  return <div className="timing-chart" role="region" aria-label={`${labels[metric]} by month`}><div className="timing-chart-bars">{months.map(item => <button type="button" key={item.month} className={selected === item.month ? 'selected' : ''} onClick={() => onSelect(item.month)} aria-label={`${item.month}: ${item[metric]}`}><i aria-hidden="true" style={{ height: `${Math.max(8, ((item[metric] - min) / range) * 100)}%` }} /></button>)}</div><div className="timing-chart-labels">{months.map(item => <button type="button" key={item.month} className={selected === item.month ? 'selected' : ''} onClick={() => onSelect(item.month)}>{item.month}</button>)}</div><div className="timing-chart-key"><span>{labels[metric]}</span><strong>{months.find(item => item.month === selected)?.[metric]}</strong></div></div>;
}
