export function SimulatorChart({ title, items, suffix = '€', selected }: { title: string; items: { label: string; value: number }[]; suffix?: string; selected?: string }) {
  const max = Math.max(...items.map(item => item.value), 1);
  return <div className="sim-chart" role="region" aria-label={title}><div className="sim-chart-title">{title}</div><div className="sim-bars">{items.map(item => <div className={`sim-bar-item ${selected === item.label ? 'selected' : ''}`} key={item.label}><span className="sim-bar-value">{suffix}{item.value.toFixed(2)}</span><div className="sim-bar" aria-hidden="true" style={{ height: `${Math.max(item.value / max * 100, 5)}%` }} /><span className="sim-bar-label">{item.label}</span></div>)}</div></div>;
}
