export function PriceSelector({ prices, selected, onChange }: { prices: number[]; selected: number; onChange: (price: number) => void }) {
  return <div className="price-selector" role="group" aria-label="Candidate prices">{prices.map(price => <button key={price} type="button" className={price === selected ? 'active' : ''} onClick={() => onChange(price)}><small>Candidate</small><strong>€{price.toFixed(2)}</strong></button>)}</div>;
}
