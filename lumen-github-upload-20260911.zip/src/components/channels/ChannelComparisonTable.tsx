import { ChannelResult } from '../../features/channels/channelModel';

export function ChannelComparisonTable({ rows, selected, onSelect }: { rows: ChannelResult[]; selected: string; onSelect: (channel: string) => void }) {
  return <div className="channel-table" role="table" aria-label="Channel comparison"><div className="channel-table-row channel-table-head" role="row"><span>Channel</span><span>Contribution</span><span>CAC</span><span>LTV:CAC</span><span>Payback</span></div>{rows.map(row => <button type="button" role="row" className={`channel-table-row ${selected === row.channel ? 'selected' : ''}`} key={row.channel} onClick={() => onSelect(row.channel)}><strong>{row.channel}</strong><span>€{row.contribution.toFixed(2)}</span><span>€{row.cac.toFixed(0)}</span><span>{row.ltvCac.toFixed(1)}×</span><span>{row.paybackUnits.toFixed(0)} units</span></button>)}</div>;
}
