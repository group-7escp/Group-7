export function ChannelMetricCard({ label, value, detail }: { label: string; value: string; detail: string }) {
  return <article className="channel-metric-card"><span>{label}</span><strong>{value}</strong><small>{detail}</small></article>;
}
