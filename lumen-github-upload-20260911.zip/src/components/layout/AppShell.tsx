import { PropsWithChildren, useState } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { getScenario, scenarios } from '../../domain/scenarios/scenarios';
import './layout.css';

const navigation = [
  { to: '/summary', label: 'Decision Home', icon: '⌂' },
  { to: '/plan', label: 'Build a Launch Plan', icon: '◇' },
  { to: '/pricing', label: 'Pricing Simulator', icon: '€' },
  { to: '/channels', label: 'Channel Analysis', icon: '≋' },
  { to: '/timing', label: 'Launch Timing', icon: '◷' },
  { to: '/market', label: 'Understand the Market', icon: '◌' },
  { to: '/validate', label: 'Validate and Share', icon: '✓' },
];

export function AppShell({ children }: PropsWithChildren) {
  const [open, setOpen] = useState(false);
  const [scenarioOpen, setScenarioOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const scenario = getScenario(new URLSearchParams(location.search).get('scenario'));
  return <div className="app-shell">
    <aside className={`sidebar ${open ? 'sidebar--open' : ''}`}>
      <div className="brand"><span className="brand-mark">L</span><span><strong>LUMEN</strong><small>Launch cockpit</small></span></div>
      <nav aria-label="Primary navigation">{navigation.map(item => <NavLink key={item.to} to={`${item.to}?scenario=${scenario.key}`} onClick={() => setOpen(false)} className={({isActive}) => `nav-item ${isActive ? 'active' : ''}`}><span aria-hidden="true">{item.icon}</span>{item.label}</NavLink>)}</nav>
      <div className="sidebar-footer"><span className="status-dot" aria-hidden="true" />{scenario.label} · Draft</div>
    </aside>
    {open && <button className="sidebar-backdrop" aria-label="Close navigation" onClick={() => setOpen(false)} />}
    <div className="main-area">
      <header className="topbar"><button className="menu-button" aria-label="Open navigation" onClick={() => setOpen(true)}>☰</button><div><span className="eyebrow">GERMANY MARKET ENTRY</span><span className="topbar-title">Decision workspace</span></div><div className="scenario-selector"><button className="scenario-pill" aria-expanded={scenarioOpen} aria-haspopup="listbox" onClick={() => setScenarioOpen(value => !value)}>{scenario.label} <span>⌄</span></button>{scenarioOpen && <div className="scenario-menu" role="listbox" aria-label="Select scenario">{Object.values(scenarios).map(option => <button role="option" aria-selected={scenario.key === option.key} key={option.key} onClick={() => { navigate(`${location.pathname}?scenario=${option.key}`); setScenarioOpen(false); }}>{option.label}</button>)}</div>}</div></header>
      <main className="page-content">{location.pathname !== '/summary' && location.pathname !== '/plan' && <NavLink className="topbar-back-link" to={`/plan?scenario=${scenario.key}`}>← Back to launch plan</NavLink>}{children}</main>
    </div>
  </div>;
}
