import { Component, ErrorInfo, PropsWithChildren, ReactNode } from 'react';

interface State { hasError: boolean; }
export class ErrorBoundary extends Component<PropsWithChildren, State> {
  state: State = { hasError: false };
  static getDerivedStateFromError(): State { return { hasError: true }; }
  componentDidCatch(_error: Error, _info: ErrorInfo) {}
  render(): ReactNode { if (!this.state.hasError) return this.props.children; return <main className="app-error"><div className="app-error-card"><span className="eyebrow">TEMPORARY ERROR</span><h1>Something went wrong</h1><p>The workspace could not render this view. Try again or return to the Decision Home.</p><button type="button" onClick={() => window.location.reload()}>Reload workspace</button></div></main>; }
}
