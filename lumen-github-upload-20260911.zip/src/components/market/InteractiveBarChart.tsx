import { useState } from 'react';

export interface BarDatum { label: string; value: number; detail: string; }

export function InteractiveBarChart({ data, suffix = '', color = 'green' }: { data: BarDatum[]; suffix?: string; color?: 'green' | 'dark' }) {
  const [active, setActive] = useState(0);
  const max = Math.max(...data.map(item => item.value), 1);
  return <div className="bar-chart" role="region" aria-label="Interactive bar chart">
    <div className="bar-chart-visual">{data.map((item, index) => <button key={item.label} className={`bar-column ${index === active ? 'selected' : ''}`} type="button" onClick={() => setActive(index)} aria-label={`${item.label}: ${item.value}${suffix}`}><span className={`bar ${color}`} style={{ height: `${Math.max(item.value / max * 100, 4)}%` }} /></button>)}</div>
    <div className="bar-chart-labels">{data.map((item, index) => <button key={item.label} type="button" className={index === active ? 'selected' : ''} onClick={() => setActive(index)}>{item.label}</button>)}</div>
    <div className="chart-tooltip"><strong>{data[active].label}: {data[active].value}{suffix}</strong><span>{data[active].detail}</span></div>
  </div>;
}
