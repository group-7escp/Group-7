export type ScenarioKey = 'premium' | 'balanced' | 'penetration';
export interface ScenarioConfig { key: ScenarioKey; label: string; price: number; demandAdjustment: number; cacAdjustment: number; positioning: string; }

export const scenarios: Record<ScenarioKey, ScenarioConfig> = {
  premium: { key: 'premium', label: 'Premium launch', price: 2.59, demandAdjustment: -48, cacAdjustment: 10, positioning: 'Premium performance' },
  balanced: { key: 'balanced', label: 'Balanced launch', price: 2.19, demandAdjustment: 0, cacAdjustment: 0, positioning: 'Accessible premium' },
  penetration: { key: 'penetration', label: 'Penetration launch', price: 1.79, demandAdjustment: 19, cacAdjustment: -8, positioning: 'Broad trial and awareness' },
};

export function getScenario(key: string | null): ScenarioConfig {
  return key && key in scenarios ? scenarios[key as ScenarioKey] : scenarios.balanced;
}
